# Automatic-Ticket-Classification
Build a model that is able to classify customer complaints based on the products/services. By doing so, we can segregate these tickets into their relevant categories and, therefore, help in the quick resolution of the issue.

Dataset can be downloaded from [here](https://www.kaggle.com/code/iswarpradhan/automatic-ticket-classification/data)


Technologies Used
#Json
#Python
#Github
#Jovian
#Jupyterhub

Contact
Created by [ISWARPRADHAN] - feel free to contact me!
